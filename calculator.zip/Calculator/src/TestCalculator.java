
public class TestCalculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	Calculator ca = new Calculator();
		
	System.out.println("Sudetis" + ca.add(20, 30));
	
	System.out.println("Cosinus" + ca.mathCos(20));
	
	System.out.println("Sinus" + ca.mathSin(30));
	
	System.out.println("Dalyba" + ca.divide(20, 30));
	
	}

}
